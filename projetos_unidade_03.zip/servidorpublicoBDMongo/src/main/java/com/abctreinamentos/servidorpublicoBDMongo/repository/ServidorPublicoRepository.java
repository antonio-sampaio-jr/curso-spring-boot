package com.abctreinamentos.servidorpublicoBDMongo.repository;

import org.springframework.stereotype.Repository;

import com.abctreinamentos.servidorpublicoBDMongo.entity.ServidorPublico;

import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

@Repository
public interface ServidorPublicoRepository extends MongoRepository<ServidorPublico, ObjectId>
{
	@Query("{ 'matricula' : ?0 }")
    Optional<ServidorPublico> findById(Long matricula);
}
