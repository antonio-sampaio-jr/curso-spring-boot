package com.abctreinamentos.servidorpublicoBDMongo.service;

import java.util.List;
import java.util.Optional;

import com.abctreinamentos.servidorpublicoBDMongo.entity.ServidorPublico;

public interface ServidorPublicoService {
	
	List<ServidorPublico> listAll();
	
	Optional<ServidorPublico> listByMatricula(long matricula); 
	
	void save(ServidorPublico servidor);
	
	void update (ServidorPublico servidor);
	
	void delete (long matricula); 
}
