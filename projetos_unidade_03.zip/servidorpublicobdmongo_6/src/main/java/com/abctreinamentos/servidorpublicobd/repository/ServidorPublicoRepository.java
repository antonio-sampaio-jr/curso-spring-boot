package com.abctreinamentos.servidorpublicobd.repository;

import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.abctreinamentos.servidorpublicobd.entity.ServidorPublico;

@Repository
public interface ServidorPublicoRepository extends MongoRepository<ServidorPublico,ObjectId> {
	
	@Query("{ 'matricula' : ?0 }")
	Optional<ServidorPublico> findById(Long matricula);
}
