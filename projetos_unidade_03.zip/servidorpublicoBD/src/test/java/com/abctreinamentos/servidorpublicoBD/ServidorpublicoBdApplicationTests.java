package com.abctreinamentos.servidorpublicoBD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServidorpublicoBdApplicationTests {

	@Test
	void contextLoads() {
	}

}
