package com.abctreinamentos.servidorpublicoBD.service;

import java.util.List;
import java.util.Optional;

import com.abctreinamentos.servidorpublicoBD.entity.ServidorPublico;

public interface ServidorPublicoService {
	
	List<ServidorPublico> listAll();
	
	Optional<ServidorPublico> listByMatricula(long matricula);
	
	void save(ServidorPublico servidor);
	
	void update (ServidorPublico servidor);
	
	void delete (long matricula);

}
