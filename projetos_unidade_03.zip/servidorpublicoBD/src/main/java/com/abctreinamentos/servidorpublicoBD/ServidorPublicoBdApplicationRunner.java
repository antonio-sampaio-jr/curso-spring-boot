package com.abctreinamentos.servidorpublicoBD;

import java.util.List;
import java.util.Optional;

import javax.swing.JOptionPane;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.abctreinamentos.servidorpublicoBD.entity.ServidorPublico;
import com.abctreinamentos.servidorpublicoBD.service.ServidorPublicoService;

@Configuration
public class ServidorPublicoBdApplicationRunner implements CommandLineRunner {

	private ServidorPublicoService servidorService;
	
	@Autowired
	public void setServidorPublicoService(ServidorPublicoService servidorService)
	{
		this.servidorService = servidorService;
	}
	
	
	public void listAll()
	{
		List<ServidorPublico> servidoresPublicos = servidorService.listAll();
		
		if (servidoresPublicos.size() != 0) 
			servidoresPublicos.forEach(servidor -> 
			{
				System.out.println("**********************************");
				System.out.println(servidor.getMatricula());
				System.out.println(servidor.getNome());
				System.out.println(servidor.getCargo());
				System.out.println(servidor.getCelular());
				System.out.println(servidor.getEmail());
				System.out.println(servidor.getOrgao());
			});
		else
			System.out.println("Arquivo Vazio!");
	}
	
	public void listByMatricula()
	{
		long matricula = Long.parseLong(JOptionPane.showInputDialog("Digite a matrícula do servidor:"));
		Optional<ServidorPublico> servidor = servidorService.listByMatricula(matricula);
		
		if (servidor.isPresent())
		{
				System.out.println("*********<<<<*************>>>>>************");
				System.out.println(servidor.get().getMatricula());
				System.out.println(servidor.get().getNome());
				System.out.println(servidor.get().getCargo());
				System.out.println(servidor.get().getCelular());
				System.out.println(servidor.get().getEmail());
				System.out.println(servidor.get().getOrgao());
		}
		else
			System.out.println("Servidor Não Encontrado");
	}
	
	public void save()
	{
		long matricula = Long.parseLong(JOptionPane.showInputDialog("Cadastro <=> Digite a matrícula do servidor:"));
		Optional<ServidorPublico> servidor = servidorService.listByMatricula(matricula);
		
		if (!servidor.isPresent())
		{
				ServidorPublico novoServidor = new ServidorPublico();
				novoServidor.setMatricula(matricula);
				
				String nome = JOptionPane.showInputDialog("Digite o nome do servidor:");
				novoServidor.setNome(nome);
				
				String foto = JOptionPane.showInputDialog("Digite a URL da foto do servidor:");
				novoServidor.setFoto(foto);
				
				String orgao = JOptionPane.showInputDialog("Digite o nome do órgão do servidor:");
				novoServidor.setOrgao(orgao);
				
				String vinculo = JOptionPane.showInputDialog("Digite o vínculo do servidor:");
				novoServidor.setVinculo(vinculo);
				
				String cargo = JOptionPane.showInputDialog("Digite o cargo do servidor:");
				novoServidor.setCargo(cargo);
				
				String lotacao = JOptionPane.showInputDialog("Digite a lotação do servidor:");
				novoServidor.setLotacao(lotacao);
				
				String exercicio = JOptionPane.showInputDialog("Digite o exercicio do servidor:");
				novoServidor.setExercicio(exercicio);
				
				String email = JOptionPane.showInputDialog("Digite o email do servidor:");
				novoServidor.setEmail(email);
				
				String telefone = JOptionPane.showInputDialog("Digite o telefone do servidor:");
				novoServidor.setTelefone(telefone);
				
				String celular = JOptionPane.showInputDialog("Digite o celular do servidor:");
				novoServidor.setCelular(celular);
				
				String cpf = JOptionPane.showInputDialog("Digite o cpf do servidor:");
				novoServidor.setCpf(cpf);
				
				String naturalidade = JOptionPane.showInputDialog("Digite a naturalidade do servidor:");
				novoServidor.setNaturalidade(naturalidade);		
				
				servidorService.save(novoServidor);
		}
		else
			System.out.println("Servidor já existe com esta matrícula");
	}
	
	public void update()
	{
		long matricula = Long.parseLong(JOptionPane.showInputDialog("Alteração <==> Digite a matrícula do servidor:"));
		Optional<ServidorPublico> servidor = servidorService.listByMatricula(matricula);
		
		if (servidor.isPresent())
		{
				String nome = JOptionPane.showInputDialog("Digite o nome do servidor para ser alterado:");
				servidor.get().setNome(nome);				
				
				servidorService.update(servidor.get());
		}
		else
			System.out.println("Servidor não existe com esta matrícula");
	}

	@Bean
	public void delete() 
	{
		long matricula = Long.parseLong(JOptionPane.showInputDialog("Digite a matrícula do servidor:"));
		Optional<ServidorPublico> servidor = servidorService.listByMatricula(matricula);
		
		if (servidor.isPresent())		
				servidorService.delete(matricula);
		else
			System.out.println("Servidor não existe com esta matrícula");
	}
	
	@Override
	public void run(String... args) throws Exception 
	{
		
	}

}
