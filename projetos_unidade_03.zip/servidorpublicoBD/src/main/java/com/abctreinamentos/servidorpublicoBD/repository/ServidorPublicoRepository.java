package com.abctreinamentos.servidorpublicoBD.repository;

import org.springframework.stereotype.Repository;
import com.abctreinamentos.servidorpublicoBD.entity.ServidorPublico;
import org.springframework.data.repository.CrudRepository;

@Repository
public interface ServidorPublicoRepository extends CrudRepository<ServidorPublico, Long>
{

}
