package com.abctreinamentos.servidorpublicobd.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.abctreinamentos.servidorpublicobd.entity.ServidorPublico;

@Repository
public interface ServidorPublicoRepository extends CrudRepository<ServidorPublico,Long> {

}
