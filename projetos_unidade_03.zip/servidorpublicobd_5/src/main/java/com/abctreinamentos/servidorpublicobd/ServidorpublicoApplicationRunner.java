package com.abctreinamentos.servidorpublicobd;

import java.util.List;
import java.util.Optional;

import javax.swing.JOptionPane;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import com.abctreinamentos.servidorpublicobd.entity.ServidorPublico;
import com.abctreinamentos.servidorpublicobd.service.ServidorPublicoService;

import jakarta.annotation.PostConstruct;

@Configuration
public class ServidorpublicoApplicationRunner implements CommandLineRunner {
	
	private ServidorPublicoService servidorService;
	
	@Autowired
	public void setServidorPublicoService(ServidorPublicoService servidorService)
	{
		this.servidorService = servidorService;
	}
	
	@PostConstruct
	public void listAll()
	{
		List<ServidorPublico> servidorespublicos = servidorService.listAll();
		
		if(servidorespublicos.size() !=0)
		{
			System.out.println("###################################");
			servidorespublicos.forEach(
					servidor -> {
						System.out.println(servidor.getMatricula());
						System.out.println(servidor.getNome());
						System.out.println(servidor.getFoto());
						System.out.println(servidor.getOrgao());
					}
			);			
		}
		else
		{
			System.out.println("Tabela sem registros");
		}
	}
	
	public void listByMatricula()
	{
		long matricula = Long.parseLong(JOptionPane.showInputDialog("Digite a matrícula procurada"));
		Optional<ServidorPublico> servidorEncontrado = servidorService.listByMatricula(matricula);
		
		if(servidorEncontrado.isPresent())
		{
			System.out.println("###################################");
			System.out.println(servidorEncontrado.get().getMatricula());
			System.out.println(servidorEncontrado.get().getNome());
			System.out.println(servidorEncontrado.get().getFoto());
			System.out.println(servidorEncontrado.get().getOrgao());
		}
		else
			System.out.println("Não existe o servidor público com a matrícula informada");
	}
	
	public void save()
	{
		long matricula = Long.parseLong(JOptionPane.showInputDialog("Digite a matrícula do novo servidor"));
		Optional<ServidorPublico> servidorEncontrado = servidorService.listByMatricula(matricula);
		
		if(!servidorEncontrado.isPresent())
		{
			ServidorPublico novoservidor = new ServidorPublico();
			novoservidor.setMatricula(matricula);
			
			String nome = JOptionPane.showInputDialog("Digite o nome do novo servidor");
			novoservidor.setNome(nome);
			
			String foto = JOptionPane.showInputDialog("Digite a foto do novo servidor");; 
			novoservidor.setFoto(foto);
			
			String orgao = JOptionPane.showInputDialog("Digite o órgão do novo servidor");;
			novoservidor.setOrgao(orgao);
			
			String vinculo = JOptionPane.showInputDialog("Digite o vínculo do novo servidor");;
			novoservidor.setVinculo(vinculo);
			
			String cargo = JOptionPane.showInputDialog("Digite o cargo do novo servidor");;
			novoservidor.setCargo(cargo);
			
			String lotacao = JOptionPane.showInputDialog("Digite a lotação do novo servidor");;
			novoservidor.setLotacao(lotacao);
			
			String exercicio = JOptionPane.showInputDialog("Digite o exercício do novo servidor");;
			novoservidor.setExercicio(exercicio);
			
			String email = JOptionPane.showInputDialog("Digite o email do novo servidor");;
			novoservidor.setEmail(email);
			
			String telefone = JOptionPane.showInputDialog("Digite o telefone do novo servidor");;
			novoservidor.setTelefone(telefone);
			
			String celular = JOptionPane.showInputDialog("Digite o celular do novo servidor");; 
			novoservidor.setCelular(celular);
			
			String cpf = JOptionPane.showInputDialog("Digite o cpf do novo servidor");;
			novoservidor.setCpf(cpf);
			
			String naturalidade = JOptionPane.showInputDialog("Digite a naturalidade do novo servidor");;
			novoservidor.setNaturalidade(naturalidade);
			
			servidorService.save(novoservidor);
			
		}
		else
			System.out.println("Servidor Público já existente!");
	}
	
	public void update()
	{
		long matricula = Long.parseLong(JOptionPane.showInputDialog("Digite a matrícula do servidor a ser alterado"));
		Optional<ServidorPublico> servidorEncontrado = servidorService.listByMatricula(matricula);
		
		if(servidorEncontrado.isPresent())
		{
			String nome = JOptionPane.showInputDialog("Digite o nome do novo servidor");
			servidorEncontrado.get().setNome(nome);
			servidorService.update(servidorEncontrado.get());	
		}
		else
			System.out.println("Servidor não encontrado");
	}
	@PostConstruct
	public void delete() 
	{
		long matricula = Long.parseLong(JOptionPane.showInputDialog("Digite a matrícula do servidor a ser excluído"));
		Optional<ServidorPublico> servidorEncontrado = servidorService.listByMatricula(matricula);
		
		if(servidorEncontrado.isPresent())
		{
			servidorService.delete(matricula);	
		}
		else
			System.out.println("Servidor não encontrado");
	}
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

	}

}
