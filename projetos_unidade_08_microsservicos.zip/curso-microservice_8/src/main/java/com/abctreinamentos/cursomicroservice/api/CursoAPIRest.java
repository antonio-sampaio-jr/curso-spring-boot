package com.abctreinamentos.cursomicroservice.api;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.abctreinamentos.cursomicroservice.entity.Curso;

public interface CursoAPIRest {
	
	@GetMapping("/listarCursos")
	public ResponseEntity<List<Curso>> listarCursos();
	
	@GetMapping("/listarCurso/{idCurso}")
	public ResponseEntity<Curso> listByIdCurso(@PathVariable("idCurso") long idCurso);
	 	
	@PostMapping("/cadastrarCurso")
	public String save(@RequestBody Curso novoCurso);
	
	@DeleteMapping("/excluirCurso/{idCurso}")
	public void deleteCurso(@PathVariable("idCurso") long idCurso);
	
	@PutMapping("/editarCurso/{idCurso}")
	public String update(@PathVariable Long idCurso, @RequestBody Curso cursoAlterado);
	
}
