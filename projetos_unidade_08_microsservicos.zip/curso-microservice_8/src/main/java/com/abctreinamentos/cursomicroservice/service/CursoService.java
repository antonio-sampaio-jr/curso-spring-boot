package com.abctreinamentos.cursomicroservice.service;

import java.util.List;
import java.util.Optional;

import com.abctreinamentos.cursomicroservice.entity.Curso;
import com.abctreinamentos.cursomicroservice.entity.ServidorPublico;

public interface CursoService {
	
	List<Curso> listAll();
	
	Optional<Curso> listByidCurso(long idCurso);
	
	void save(Curso curso);
	
	void update (Curso curso);
	
	void delete (long idCurso);
	
	List<ServidorPublico> findServidoresCurso(long idcurso); 
}
