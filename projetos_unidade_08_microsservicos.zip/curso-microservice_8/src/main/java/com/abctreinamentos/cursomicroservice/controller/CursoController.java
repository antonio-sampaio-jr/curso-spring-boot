package com.abctreinamentos.cursomicroservice.controller;

import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.abctreinamentos.cursomicroservice.api.CursoAPIRest;
import com.abctreinamentos.cursomicroservice.entity.Curso;
import com.abctreinamentos.cursomicroservice.entity.ServidorPublico;
import com.abctreinamentos.cursomicroservice.service.CursoService;

@RestController
@RequestMapping("curso")
public class CursoController implements CursoAPIRest{
	
	private CursoService cursoService;
	
	@Autowired
	public void setCursoService(CursoService cursoService)
	{
		this.cursoService = cursoService;
	} 
	
	//Implementação da API Rest - Curso
	@GetMapping("/listarCursos")
	public ResponseEntity<List<Curso>> listarCursos() {
		List<Curso> list = cursoService.listAll();
	    return new ResponseEntity<List<Curso>>(list, HttpStatus.OK);
	}
	

	@GetMapping("/listarCurso/{idCurso}")
	public ResponseEntity<Curso> listByIdCurso(@PathVariable("idCurso") long idCurso) {

		if (cursoService.listByidCurso(idCurso).isPresent())
			return new ResponseEntity<Curso>(cursoService.listByidCurso(idCurso).get(),HttpStatus.OK);
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Curso Não Encontrado");
	}
		
	@PostMapping("/cadastrarCurso")
	public String save(@RequestBody Curso novoCurso)
	{
		cursoService.save(novoCurso);
		throw new ResponseStatusException(HttpStatus.CREATED, "Curso Cadastrado");
	}

	@DeleteMapping("/excluirCurso/{idCurso}")
	public void deleteCurso(@PathVariable("idCurso") long idCurso) 
	{
		if (cursoService.listByidCurso(idCurso).isPresent())
		{	
			cursoService.delete(idCurso);
			throw new ResponseStatusException(HttpStatus.OK, "Curso Excluído");
		}	
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Erro na Exclusão! Curso Não Encontrado");
	}   

	@PutMapping("/editarCurso/{idCurso}")
	public String update(@PathVariable Long idCurso, @RequestBody Curso cursoAlterado) {
		if (cursoService.listByidCurso(idCurso).isPresent())
		{	
			cursoService.update(cursoAlterado);
			throw new ResponseStatusException(HttpStatus.OK, "Curso Alterado");
		}	
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Erro na Alteração! Curso Não Encontrado");
	}
	
	@ExceptionHandler(ResponseStatusException.class)
	 public ResponseEntity<?> handleResponseStatusException(ResponseStatusException ex) {
		Map<String, Object> body = new LinkedHashMap<>(); 
	    body.put("message", ex.getReason()); 
	    body.put("status", ex.getStatusCode()); 
	    return new ResponseEntity<>(body, ex.getStatusCode());
	 }

	//Chamada à API ServidorPublico
	@GetMapping("/listarServidores/{idcurso}")
    public ResponseEntity<List<ServidorPublico>> findServidoresByCursoId(
            @PathVariable("idcurso") long idcurso) {
        
		List<ServidorPublico> servidores = cursoService.findServidoresCurso(idcurso);
        
		if ((servidores != null && !servidores.isEmpty()))
			return new ResponseEntity<List<ServidorPublico>>(servidores,HttpStatus.OK);
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Servidores Públicos Não Encontrados");

    }
}
