package com.abctreinamentos.cursomicroservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abctreinamentos.cursomicroservice.client.ServidorPublicoServiceClient;
import com.abctreinamentos.cursomicroservice.entity.Curso;
import com.abctreinamentos.cursomicroservice.entity.ServidorPublico;
import com.abctreinamentos.cursomicroservice.repository.CursoRepository;


@Service
public class CursoServiceImpl implements CursoService {
	
	@Autowired
    private CursoRepository cursoRepository;
	
	private final ServidorPublicoServiceClient servidorPublicoClient;
	
	//a injeção via construtor é geralmente considerada uma prática recomendada.
	public CursoServiceImpl(ServidorPublicoServiceClient servidorPublicoClient) {
        this.servidorPublicoClient = servidorPublicoClient;
    }
	
	@Override 
	public List<Curso> listAll() 
	{
		List<Curso> cursos = new ArrayList<>();
		cursoRepository.findAll().forEach(cursos::add);
		return cursos;
	}

	@Override
	public Optional<Curso> listByidCurso(long idCurso) {
		
		return cursoRepository.findById(idCurso);
	}

	@Override
	public void save(Curso curso) {
		cursoRepository.save(curso);		
	}

	@Override
	public void update(Curso curso) {
		Optional<Curso> cursoEncontrado = cursoRepository.findById(curso.getIdcurso());
		cursoEncontrado.ifPresent(p -> {
			cursoRepository.save(curso);
		});
		
	}

	@Override
	public void delete(long idCurso) {
		Optional<Curso> cursoEncontrado = cursoRepository.findById(idCurso);
		cursoEncontrado.ifPresent(p -> {
			cursoRepository.delete(cursoEncontrado.get());
		});
		
	}

	@Override
	public List<ServidorPublico> findServidoresCurso(long idcurso) {
		
		Optional<Curso> cursoEncontrado = cursoRepository.findById(idcurso);
		
		if (cursoEncontrado.isPresent()) {
			List<ServidorPublico> response = servidorPublicoClient.findAllByCursoId(idcurso);
		    return response;
		} else {
		    // Realizar uma ação apropriada quando o curso não for encontrado, por exemplo:
		    return null;
		}
	}

}
