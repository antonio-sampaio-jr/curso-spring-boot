package com.abctreinamentos.cursomicroservice.repository;

import org.springframework.stereotype.Repository;

import com.abctreinamentos.cursomicroservice.entity.Curso;


import org.springframework.data.repository.CrudRepository;

@Repository
public interface CursoRepository extends CrudRepository<Curso, Long>
{
	
}
