package com.abctreinamentos.cursomicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursoMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
