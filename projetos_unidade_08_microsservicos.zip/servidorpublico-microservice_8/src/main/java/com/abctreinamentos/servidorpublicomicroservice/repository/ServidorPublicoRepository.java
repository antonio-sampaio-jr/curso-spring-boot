package com.abctreinamentos.servidorpublicomicroservice.repository;

import org.springframework.stereotype.Repository;

import com.abctreinamentos.servidorpublicomicroservice.entity.ServidorPublico;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface ServidorPublicoRepository extends JpaRepository<ServidorPublico, Long>
{
	List<ServidorPublico> findAllByIdcurso(Long idcurso);
}
