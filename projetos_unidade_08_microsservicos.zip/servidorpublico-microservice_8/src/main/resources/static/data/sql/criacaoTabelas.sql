CREATE TABLE siscapacit.Curso (
    idcurso INT AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    foto VARCHAR(80) NOT NULL,
    formaRealizacao VARCHAR(45) NOT NULL,
    ofertante VARCHAR(60) NOT NULL,
    vagas INT NOT NULL,
    valor INT NOT NULL,
    site VARCHAR(200) NOT NULL,
    situacao VARCHAR(45) NOT NULL,
    PRIMARY KEY (`idcurso`),
    UNIQUE KEY `idcurso_UNIQUE` (`idcurso`)
);

CREATE TABLE siscapacit.ServidorPublico (
  `matricula` INT NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `foto` VARCHAR(60) NOT NULL,
  `orgao` VARCHAR(45) NOT NULL,
  `vinculo` VARCHAR(45) NOT NULL,
  `cargo` VARCHAR(45) NOT NULL,
  `lotacao` VARCHAR(45) NOT NULL,
  `exercicio` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `telefone` VARCHAR(45) NOT NULL,
  `celular` VARCHAR(45) NOT NULL,
  `cpf` VARCHAR(45) NOT NULL,
  `naturalidade` VARCHAR(45) NOT NULL,
  `idcurso` INT,
  PRIMARY KEY (`matricula`),
  UNIQUE KEY `matricula_UNIQUE` (`matricula`),
  FOREIGN KEY (`idcurso`) REFERENCES `Curso` (`idcurso`)
);



