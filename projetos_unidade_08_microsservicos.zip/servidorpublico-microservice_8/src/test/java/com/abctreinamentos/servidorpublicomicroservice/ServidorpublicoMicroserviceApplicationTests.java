package com.abctreinamentos.servidorpublicomicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServidorpublicoMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
