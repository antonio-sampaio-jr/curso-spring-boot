package com.abctreinamentos.servidorpublicobdwebrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServidorpublicobdwebRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServidorpublicobdwebRestApiApplication.class, args);
	}

}
