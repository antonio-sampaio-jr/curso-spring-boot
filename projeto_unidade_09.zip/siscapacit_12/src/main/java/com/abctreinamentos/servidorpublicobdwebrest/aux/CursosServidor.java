package com.abctreinamentos.servidorpublicobdwebrest.aux;

import java.util.List;
import java.util.Map;

import com.abctreinamentos.servidorpublicobdwebrest.entity.Curso;
import com.abctreinamentos.servidorpublicobdwebrest.entity.ServidorPublico;

public record CursosServidor(Map<String, List<Curso>> cursos,
		ServidorPublico servidor) {
}
