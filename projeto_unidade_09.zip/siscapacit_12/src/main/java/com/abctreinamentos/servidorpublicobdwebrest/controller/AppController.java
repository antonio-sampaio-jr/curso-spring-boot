package com.abctreinamentos.servidorpublicobdwebrest.controller;

import java.util.List;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.abctreinamentos.servidorpublicobdwebrest.api.CursoAPIRest;
import com.abctreinamentos.servidorpublicobdwebrest.api.ServidorPublicoAPIRest;
import com.abctreinamentos.servidorpublicobdwebrest.aux.CursosServidor;
import com.abctreinamentos.servidorpublicobdwebrest.aux.ServidoresCurso;
import com.abctreinamentos.servidorpublicobdwebrest.entity.Curso;
import com.abctreinamentos.servidorpublicobdwebrest.entity.ServidorPublico;
import com.abctreinamentos.servidorpublicobdwebrest.service.CursoService;
import com.abctreinamentos.servidorpublicobdwebrest.service.ServidorPublicoService;

@RestController
public class AppController implements ServidorPublicoAPIRest, CursoAPIRest{
	
	private ServidorPublicoService servidorService;
	private CursoService cursoService;
	
	@Autowired
	public void setServidorPublicoService(ServidorPublicoService servidorService)
	{
		this.servidorService = servidorService;
	}
	
	@Autowired
	public void setCursoService(CursoService cursoService)
	{
		this.cursoService = cursoService;
	}

	/*********** API SERVIDORPUBLICO *************/
	@GetMapping("/listarServidores")
	public ResponseEntity<List<ServidorPublico>> listarServidores() {
		List<ServidorPublico> servidorespublicos = servidorService.listAll();
		return new ResponseEntity<List<ServidorPublico>>(servidorespublicos,HttpStatus.OK);
	}

	@GetMapping("/listarServidor/{matricula}")
	public ResponseEntity<ServidorPublico> listarServidor(long matricula) {
		
		Optional<ServidorPublico> servidorEncontrado = servidorService.listByMatricula(matricula);
		
		if (servidorEncontrado.isPresent())
			return new ResponseEntity<ServidorPublico>(servidorEncontrado.get(),HttpStatus.OK);
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Servidor Público Não Encontrado");
	}

	@DeleteMapping("/excluirServidor/{matricula}")
	public void excluirServidor(long matricula) {
		
		Optional<ServidorPublico> servidorEncontrado = servidorService.listByMatricula(matricula);
		
		if (servidorEncontrado.isPresent())
		{
			servidorService.delete(matricula);
			throw new ResponseStatusException(HttpStatus.OK,"Servidor Público Excluído");
		}
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Servidor Público Não Encontrado");
	}

	@PutMapping("/editarServidor/{matricula}")
	public String editarServidor(long matricula, @RequestBody ServidorPublico servidorAlterado) {
		
		Optional<ServidorPublico> servidorEncontrado = servidorService.listByMatricula(matricula);
		
		if (servidorEncontrado.isPresent())
		{
			servidorService.update(servidorAlterado);
			throw new ResponseStatusException(HttpStatus.OK,"Servidor Público Alterado");
		}
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Servidor Público Não Encontrado");

	}

	@PostMapping("/cadastrarServidor")
	public String cadastrarServidor(@RequestBody ServidorPublico novoservidor) {
		
		Optional<ServidorPublico> servidorEncontrado = servidorService.listByMatricula(novoservidor.getMatricula());
		
		if (!servidorEncontrado.isPresent())
		{
			servidorService.save(novoservidor);
			throw new ResponseStatusException(HttpStatus.OK,"Servidor Público Cadastrado");
		}
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Servidor Público Já Existente");	
	}
	
	/*********** API CURSO *************/
	@GetMapping("/listarCursos")
	public ResponseEntity<List<Curso>> listarCursos() {
		List<Curso> cursos = cursoService.listAll();
		return new ResponseEntity<List<Curso>>(cursos,HttpStatus.OK);
	}

	@GetMapping("/listarCurso/{idcurso}")
	public ResponseEntity<Curso> listarCurso(long idcurso) {
		
		Optional<Curso> cursoEncontrado = cursoService.listByidCurso(idcurso);
		
		if (cursoEncontrado.isPresent())
			return new ResponseEntity<Curso>(cursoEncontrado.get(),HttpStatus.OK);
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Curso Não Encontrado");
	}

	@DeleteMapping("/excluirCurso/{idcurso}")
	public void excluirCurso(long idcurso) {
		
		Optional<Curso> cursoEncontrado = cursoService.listByidCurso(idcurso);
		
		if (cursoEncontrado.isPresent())
		{
			cursoService.delete(idcurso);
			throw new ResponseStatusException(HttpStatus.OK,"Curso Excluído");
		}
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Curso Não Encontrado");
	}

	@PutMapping("/editarCurso/{idcurso}")
	public String editarCurso(long idcurso, @RequestBody Curso cursoAlterado) {
		
		Optional<Curso> cursoEncontrado = cursoService.listByidCurso(idcurso);
		
		if (cursoEncontrado.isPresent())
		{
			cursoService.update(cursoAlterado);
			throw new ResponseStatusException(HttpStatus.OK,"Curso Alterado");
		}
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Curso Não Encontrado");

	}

	@PostMapping("/cadastrarCurso")
	public String cadastrarCurso(@RequestBody Curso novocurso) {
		
		cursoService.save(novocurso);
		throw new ResponseStatusException(HttpStatus.CREATED,"Curso Cadastrado");
	}
	
	/*********** API SERVIDORPUBLICOCURSO *************/
	
	@PostMapping("/matricularServidorCurso/{idcurso}")
	public String matricular(@RequestBody ServidorPublico servidor, @PathVariable long idcurso)
	{
		Curso curso = cursoService.listByidCurso(idcurso).get();
		// Adicione o servidorPublicoCurso à lista cursos em ServidorPublico
		servidor.getCursos().add(curso);
		servidorService.matricular(servidor);
		throw new ResponseStatusException(HttpStatus.OK, "Servidor Matriculado no Curso");
	}
	
	@PostMapping("/desmatricularServidorCurso/{idcurso}")
	public String desmatricular(@RequestBody ServidorPublico servidor, @PathVariable long idcurso)
	{
		Curso curso = cursoService.listByidCurso(idcurso).get();
		servidor.getCursos().remove(curso);
		servidorService.desmatricular(servidor);
		throw new ResponseStatusException(HttpStatus.OK, "Servidor Desmatriculado do Curso");
	}
	
	@GetMapping("/listarCursosServidor/{matricula}")
	public ResponseEntity<CursosServidor> listarCursosServidor(@PathVariable Long matricula) 
	{
		Optional<ServidorPublico> servidorEncontrado =	servidorService.listByMatricula(matricula);
		List<Curso> todosCursos = cursoService.listAll();
		List<Curso> cursosListados = new ArrayList<>();
		List<Curso> cursosNaoListados = new ArrayList<>();
	
		for (Curso curso : todosCursos) 
		{	
			List<ServidorPublico> servidores = curso.getServidores();	
					
			if (servidores != null && servidores.stream().anyMatch
					(servidor -> servidor.getMatricula().equals(matricula))) { 
						cursosListados.add(curso);} 
			else 
				cursosNaoListados.add(curso);
		}	
		// Retornar as duas listas no corpo da resposta
		Map<String, List<Curso>> cursosMap = new HashMap<>();
		cursosMap.put("Cursos Matriculados", cursosListados);
		cursosMap.put("Cursos Não Matriculados", cursosNaoListados);
		CursosServidor cursosservidor = new CursosServidor(cursosMap,servidorEncontrado.get());
		return new ResponseEntity<>(cursosservidor, HttpStatus.OK);
	}
	
	@GetMapping("/listarServidoresCurso/{idcurso}")
	public ResponseEntity<ServidoresCurso> listarServidoresCurso(@PathVariable Long idcurso) {
		
		Curso cursoEncontrado = cursoService.listByidCurso(idcurso).get();
		List<ServidorPublico> servidores = cursoEncontrado.getServidores();
		Map<String, List<ServidorPublico>> servidoresMap = new HashMap<>();
		servidoresMap.put("Servidores Públicos Matriculados", servidores);
		ServidoresCurso servidorescurso = new ServidoresCurso(servidoresMap, cursoEncontrado);
		return new ResponseEntity<>(servidorescurso, HttpStatus.OK);
	}
	
	@ExceptionHandler(ResponseStatusException.class)
	public ResponseEntity<Object> handleNotFoundException(ResponseStatusException ex) {
		Map<String, Object> body = new LinkedHashMap<>();
		body.put("message", ex.getReason());
		body.put("status", ex.getStatusCode());
		return new ResponseEntity<>(body, ex.getStatusCode());
	}
}
