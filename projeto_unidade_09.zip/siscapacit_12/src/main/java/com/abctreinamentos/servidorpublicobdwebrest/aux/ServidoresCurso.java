package com.abctreinamentos.servidorpublicobdwebrest.aux;

import java.util.List;
import java.util.Map;

import com.abctreinamentos.servidorpublicobdwebrest.entity.Curso;
import com.abctreinamentos.servidorpublicobdwebrest.entity.ServidorPublico;

public record ServidoresCurso(Map<String, List<ServidorPublico>> servidores,
		Curso curso) 
{

}