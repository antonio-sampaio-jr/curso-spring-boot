CREATE TABLE ServidorPublico (
  `matricula` int PRIMARY KEY NOT NULL,
  `nome` varchar(45) NOT NULL,
  `foto` varchar(60) NOT NULL,
  `orgao` varchar(45) NOT NULL,
  `vinculo` varchar(45) NOT NULL,
  `cargo` varchar(45) NOT NULL,
  `lotacao` varchar(45) NOT NULL,
  `exercicio` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `telefone` varchar(45) NOT NULL,
  `celular` varchar(45) NOT NULL,
  `cpf` varchar(45) NOT NULL,
  `naturalidade` varchar(45) NOT NULL
);

CREATE TABLE Curso (
    idcurso INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    foto VARCHAR(80) NOT NULL,
    formaRealizacao VARCHAR(45) NOT NULL,
    ofertante VARCHAR(60) NOT NULL,
    vagas INT NOT NULL,
    valor INT NOT NULL,
    site VARCHAR(200) NOT NULL,
    situacao VARCHAR(45) NOT NULL
);

CREATE TABLE ServidorPublicoCurso (
  matricula INT,
  idcurso INT,
  PRIMARY KEY (matricula, idcurso),
  FOREIGN KEY (matricula) REFERENCES ServidorPublico(matricula) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (idcurso) REFERENCES Curso(idcurso) ON DELETE CASCADE ON UPDATE CASCADE
);

