package com.abctreinamentos.servidorpublicoBDRestAPI.repository;

import org.springframework.stereotype.Repository;

import com.abctreinamentos.servidorpublicoBDRestAPI.entity.ServidorPublico;

import org.springframework.data.repository.CrudRepository;

@Repository
public interface ServidorPublicoRepository extends CrudRepository<ServidorPublico, Long>
{

}
