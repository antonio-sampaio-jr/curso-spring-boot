package com.abctreinamentos.servidorpublicoBDRestAPI.controller;

import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.server.ResponseStatusException;

import com.abctreinamentos.servidorpublicoBDRestAPI.api.ServidorpublicoAPIRest;
import com.abctreinamentos.servidorpublicoBDRestAPI.entity.ServidorPublico;
import com.abctreinamentos.servidorpublicoBDRestAPI.service.ServidorPublicoService;

@Controller
public class ServidorPublicoController implements ServidorpublicoAPIRest{
	
	private ServidorPublicoService servidorService;
	
	@Autowired
	public void setServidorPublicoService(ServidorPublicoService servidorService)
	{
		this.servidorService = servidorService;
	} 
	
	//Implementação da API Rest
	@GetMapping("/listarServidores")
	public ResponseEntity<List<ServidorPublico>> listarServidores() {
		List<ServidorPublico> list = servidorService.listAll();
        return new ResponseEntity<List<ServidorPublico>>(list, HttpStatus.OK);
	}

	@GetMapping("/listarServidor/{matricula}")
	public ResponseEntity<ServidorPublico> listByMatricula(@PathVariable("matricula") long matricula) {
		
		if (servidorService.listByMatricula(matricula).isPresent())
			return new ResponseEntity<ServidorPublico>(servidorService.listByMatricula(matricula).get(),HttpStatus.OK);
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Servidor Público Não Encontrado");
	}
	
	@PostMapping("/cadastrarServidor")
	public String save(@RequestBody ServidorPublico novoServidor)
	{
		if (!servidorService.listByMatricula(novoServidor.getMatricula()).isPresent())
		{	
			servidorService.save(novoServidor);
			throw new ResponseStatusException(HttpStatus.CREATED, "Servidor Público Cadastrado");
		}	
		else
			throw new ResponseStatusException(HttpStatus.FOUND, "Servidor Público Já Existente");
	}
	
	@DeleteMapping("/excluirServidor/{matricula}")
	public void delete(@PathVariable("matricula") long matricula) 
	{
		if (servidorService.listByMatricula(matricula).isPresent())
		{	
			servidorService.delete(matricula);
			throw new ResponseStatusException(HttpStatus.OK, "Servidor Público Excluído");
		}	
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Erro na Exclusão! Servidor Público Não Encontrado");
	}   
	
	@PutMapping("/editarServidor/{matricula}")
	public String update(@PathVariable Long matricula, @RequestBody ServidorPublico servidorAlterado) {
		 if (servidorService.listByMatricula(matricula).isPresent())
		 {	
			servidorService.update(servidorAlterado);
			throw new ResponseStatusException(HttpStatus.OK, "Servidor Público Alterado");
		 }	
		 else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Erro na Alteração! Servidor Público Não Encontrado");
	}
	
	@ExceptionHandler(ResponseStatusException.class)
	 public ResponseEntity<?> handleResponseStatusException(ResponseStatusException ex) {
		Map<String, Object> body = new LinkedHashMap<>(); 
	    body.put("message", ex.getReason()); 
	    body.put("status", ex.getStatusCode()); 
	    return new ResponseEntity<>(body, ex.getStatusCode());
	 }
	
}
