package com.abctreinamentos.servidorpublicoBDWeb.controller;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.abctreinamentos.servidorpublicoBDWeb.entity.ServidorPublico;
import com.abctreinamentos.servidorpublicoBDWeb.service.ServidorPublicoService;

@Controller
public class ServidorPublicoController {
	
private ServidorPublicoService servidorService;
	
	@Autowired
	public void setServidorPublicoService(ServidorPublicoService servidorService)
	{
		this.servidorService = servidorService;
	}
	
	@GetMapping("/listarServidores")
	public String listarServidores(Model model)
	{
		model.addAttribute("servidorespublicos", servidorService.listAll());
        return "servidorespublicos";
	}
	
	@GetMapping("/listarServidor/{matricula}")
	public String listByMatricula(@PathVariable("matricula") long matricula, Model model)
	{
		model.addAttribute("servidorpublico", servidorService.listByMatricula(matricula).get());
	    return "servidorpublico";	
	}
	
	@GetMapping("/excluirServidor/{matricula}")
	public String delete(@PathVariable("matricula") long matricula, Model model) 
	{
		servidorService.delete(matricula);
		return "redirect:/listarServidores";
	}   
	
	@GetMapping("/formularioNovoServidor")
	public String formNovoServidor(Model model) {
	    model.addAttribute("servidorPublico", new ServidorPublico());
	    return "novoservidorpublico";
	}
	
	@PostMapping("/cadastrarServidor")
	public String save(@ModelAttribute ServidorPublico novoServidor)
	{
		if (!servidorService.listByMatricula(novoServidor.getMatricula()).isPresent())
			servidorService.save(novoServidor);
		else
			return "redirect:/mensagem";
		return "redirect:/listarServidores";
	}
	
	@GetMapping("/mensagem")
	public String mensagem(Model model) {
		model.addAttribute("erroMatriculaExistente", true);
	    return "/erro/mensagem";
	}
	
	@GetMapping("/formularioEditarServidor/{matricula}")
    public String formularioEditarServidor(@PathVariable Long matricula, Model model) {
		Optional<ServidorPublico> servidorEncontrado = servidorService.listByMatricula(matricula);
		model.addAttribute("servidorPublico", servidorEncontrado);
        return "editarservidorpublico";
    }

    @PostMapping("/editarServidor/{matricula}")
    public String update(@PathVariable Long matricula, @ModelAttribute ServidorPublico servidor) {
    	System.out.println("/entrou");
    	servidorService.update(servidor);
        return "redirect:/listarServidores";
    }

}
