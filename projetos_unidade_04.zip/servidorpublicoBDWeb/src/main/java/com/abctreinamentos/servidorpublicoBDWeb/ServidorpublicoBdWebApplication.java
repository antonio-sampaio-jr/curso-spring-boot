package com.abctreinamentos.servidorpublicoBDWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServidorpublicoBdWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServidorpublicoBdWebApplication.class, args);
	}

} 
