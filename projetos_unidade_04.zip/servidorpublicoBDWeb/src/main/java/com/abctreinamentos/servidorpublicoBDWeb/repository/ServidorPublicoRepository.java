package com.abctreinamentos.servidorpublicoBDWeb.repository;

import org.springframework.stereotype.Repository;

import com.abctreinamentos.servidorpublicoBDWeb.entity.ServidorPublico;
import org.springframework.data.repository.CrudRepository;

@Repository
public interface ServidorPublicoRepository extends CrudRepository<ServidorPublico, Long>
{

}
