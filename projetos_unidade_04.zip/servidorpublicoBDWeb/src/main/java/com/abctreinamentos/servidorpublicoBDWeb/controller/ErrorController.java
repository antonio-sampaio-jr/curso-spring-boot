package com.abctreinamentos.servidorpublicoBDWeb.controller;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class ErrorController implements org.springframework.boot.web.servlet.error.ErrorController {

	    @RequestMapping("/error")
	    public String handleError(HttpServletRequest request) {
	        // Obtenha o código de status do erro
	        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
	        
	        // Personalize a página de erro com base no código de status do erro
	        if (status != null) {
	            Integer statusCode = Integer.valueOf(status.toString());
	            if(statusCode == HttpStatus.NOT_FOUND.value()) {
	                return "/erro/404";
	            }
	            else if(statusCode == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
	                return "/erro/500";
	            }
	        }
	        
	        // Retorne a página de erro padrão
	        return "error";
	    }
	    
	    public String getErrorPath() {
	        return "/error";
	    }

}
