package com.abctreinamentos.mensagens;

import javax.swing.JOptionPane;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MensagensApplication {

	public static void main(String[] args) {
		System.setProperty("java.awt.headless", "false");
		SpringApplication.run(MensagensApplication.class, args);
		JOptionPane.showMessageDialog(null, "Primeiro Projeto Spring Boot");
		System.out.println("Primeiro Projeto Spring Boot");
		create();
		read();
		update();
		delete();
		
	}
	
	public static void create()
	{
		System.out.println("Criação de um Registro");
	}
	
	public static void read()
	{
		System.out.println("Leitura de um Registro");
	}
	
	public static void update()
	{
		System.out.println("Atualização de um Registro");
	}
	
	public static void delete()
	{
		System.out.println("Exclusão de um Registro");
	}

}
