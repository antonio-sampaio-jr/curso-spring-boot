package com.abctreinamentos.servidorpublicoBDRestAPI.controller;

import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.server.ResponseStatusException;

import com.abctreinamentos.servidorpublicoBDRestAPI.api.ServidorpublicoAPIRest;
import com.abctreinamentos.servidorpublicoBDRestAPI.entity.Curso;
import com.abctreinamentos.servidorpublicoBDRestAPI.entity.ServidorPublico;
import com.abctreinamentos.servidorpublicoBDRestAPI.service.CursoService;
import com.abctreinamentos.servidorpublicoBDRestAPI.service.ServidorPublicoService;

@Controller
public class AppController implements ServidorpublicoAPIRest{
	
	private ServidorPublicoService servidorService;
	private CursoService cursoService;
	
	@Autowired
	public void setServidorPublicoService(ServidorPublicoService servidorService)
	{
		this.servidorService = servidorService;
	} 
	
	@Autowired
	public void setCursoService(CursoService cursoService)
	{
		this.cursoService = cursoService;
	} 
	
	//Implementação da API Rest - Servidor Público
	@GetMapping("/listarServidores")
	public ResponseEntity<List<ServidorPublico>> listarServidores() {
		List<ServidorPublico> list = servidorService.listAll();
        return new ResponseEntity<List<ServidorPublico>>(list, HttpStatus.OK);
	}

	@GetMapping("/listarServidor/{matricula}")
	public ResponseEntity<ServidorPublico> listByMatricula(@PathVariable("matricula") long matricula) {
		
		if (servidorService.listByMatricula(matricula).isPresent())
			return new ResponseEntity<ServidorPublico>(servidorService.listByMatricula(matricula).get(),HttpStatus.OK);
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Servidor Público Não Encontrado");
	}
	
	@PostMapping("/cadastrarServidor")
	public String save(@RequestBody ServidorPublico novoServidor)
	{
		if (!servidorService.listByMatricula(novoServidor.getMatricula()).isPresent())
		{	
			servidorService.save(novoServidor);
			throw new ResponseStatusException(HttpStatus.CREATED, "Servidor Público Cadastrado");
		}	
		else
			throw new ResponseStatusException(HttpStatus.FOUND, "Servidor Público Já Existente");
	}
	
	@DeleteMapping("/excluirServidor/{matricula}")
	public void delete(@PathVariable("matricula") long matricula) 
	{
		if (servidorService.listByMatricula(matricula).isPresent())
		{	
			servidorService.delete(matricula);
			throw new ResponseStatusException(HttpStatus.OK, "Servidor Público Excluído");
		}	
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Erro na Exclusão! Servidor Público Não Encontrado");
	}   
	
	@PutMapping("/editarServidor/{matricula}")
	public String update(@PathVariable Long matricula, @RequestBody ServidorPublico servidorAlterado) {
		 if (servidorService.listByMatricula(matricula).isPresent())
		 {	
			servidorService.update(servidorAlterado);
			throw new ResponseStatusException(HttpStatus.OK, "Servidor Público Alterado");
		 }	
		 else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Erro na Alteração! Servidor Público Não Encontrado");
	}
	
	//Implementação da API Rest - Curso
	@GetMapping("/listarCursos")
	public ResponseEntity<List<Curso>> listarCursos() {
		List<Curso> list = cursoService.listAll();
	    return new ResponseEntity<List<Curso>>(list, HttpStatus.OK);
	}

	@GetMapping("/listarCurso/{idCurso}")
	public ResponseEntity<Curso> listByIdCurso(@PathVariable("idCurso") long idCurso) {

		if (cursoService.listByidCurso(idCurso).isPresent())
			return new ResponseEntity<Curso>(cursoService.listByidCurso(idCurso).get(),HttpStatus.OK);
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Curso Não Encontrado");
	}
		
	@PostMapping("/cadastrarCurso")
	public String save(@RequestBody Curso novoCurso)
	{
		cursoService.save(novoCurso);
		throw new ResponseStatusException(HttpStatus.CREATED, "Curso Cadastrado");
	}

	@DeleteMapping("/excluirCurso/{idCurso}")
	public void deleteCurso(@PathVariable("idCurso") long idCurso) 
	{
		if (cursoService.listByidCurso(idCurso).isPresent())
		{	
			cursoService.delete(idCurso);
			throw new ResponseStatusException(HttpStatus.OK, "Curso Excluído");
		}	
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Erro na Exclusão! Curso Não Encontrado");
	}   

	@PutMapping("/editarCurso/{idCurso}")
	public String update(@PathVariable Long idCurso, @RequestBody Curso cursoAlterado) {
		if (cursoService.listByidCurso(idCurso).isPresent())
		{	
			cursoService.update(cursoAlterado);
			throw new ResponseStatusException(HttpStatus.OK, "Curso Alterado");
		}	
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Erro na Alteração! Curso Não Encontrado");
	}
	
	@ExceptionHandler(ResponseStatusException.class)
	 public ResponseEntity<?> handleResponseStatusException(ResponseStatusException ex) {
		Map<String, Object> body = new LinkedHashMap<>(); 
	    body.put("message", ex.getReason()); 
	    body.put("status", ex.getStatusCode()); 
	    return new ResponseEntity<>(body, ex.getStatusCode());
	 }
	
}
