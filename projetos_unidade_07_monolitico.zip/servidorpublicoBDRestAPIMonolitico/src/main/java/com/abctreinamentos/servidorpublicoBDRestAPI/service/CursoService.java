package com.abctreinamentos.servidorpublicoBDRestAPI.service;

import java.util.List;
import java.util.Optional;

import com.abctreinamentos.servidorpublicoBDRestAPI.entity.Curso;

public interface CursoService {
	
	List<Curso> listAll();
	
	Optional<Curso> listByidCurso(long idCurso);
	
	void save(Curso curso);
	
	void update (Curso curso);
	
	void delete (long idCurso);

}
