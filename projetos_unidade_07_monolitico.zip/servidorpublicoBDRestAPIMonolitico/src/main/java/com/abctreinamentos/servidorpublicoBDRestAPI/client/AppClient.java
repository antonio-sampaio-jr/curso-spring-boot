package com.abctreinamentos.servidorpublicoBDRestAPI.client;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import com.abctreinamentos.servidorpublicoBDRestAPI.entity.ServidorPublico;
import com.abctreinamentos.servidorpublicoBDRestAPI.entity.Curso;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.HttpEntity;


@Controller
public class AppClient {
	
	@Autowired
    private RestTemplate restTemplate;
	
	/***** API SERVIDORES PÚBLICOS ******/

    @GetMapping("/listagemServidores")
    public String getServidores(Model model) {
        
    	ResponseEntity<List<ServidorPublico>> response = restTemplate.exchange(
                "http://localhost:8080/listarServidores", HttpMethod.GET, null,
                new ParameterizedTypeReference<List<ServidorPublico>>() {});
        
    	List<ServidorPublico> servidoresEncontrados = response.getBody();

    	// Adicione os dados dos clientes ao model
    	model.addAttribute("servidorespublicos", servidoresEncontrados);

    	// Retorne a view Thymeleaf para renderização
    	return "servidorpublico/servidorespublicos";
    }
    
    @GetMapping("/listagemServidor/{matricula}")
	public String listByMatricula(@PathVariable("matricula") long matricula, Model model)
	{
    	ResponseEntity<ServidorPublico> response = restTemplate.exchange(
                "http://localhost:8080/listarServidor/{matricula}", HttpMethod.GET, null,
                new ParameterizedTypeReference<ServidorPublico>() {},matricula);
        
    	ServidorPublico servidorEncontrado = response.getBody();

    	model.addAttribute("servidorpublico", servidorEncontrado);
    	
   	    return "servidorpublico/servidorpublico";	
	}
	
	@GetMapping("/exclusaoServidor/{matricula}")
	public String delete(@PathVariable("matricula") long matricula) 
	{
		ResponseEntity<Void> response = restTemplate.exchange(
                "http://localhost:8080/excluirServidor/{matricula}", HttpMethod.DELETE, null,Void.class,
                matricula);
		
		return "redirect:/listagemServidores";
	}   
	
	@GetMapping("/formNovoServidor")
	public String formNovoServidor(Model model) {
	    model.addAttribute("servidorPublico", new ServidorPublico());
	    return "servidorpublico/novoservidorpublico";
	}
	
	@PostMapping("/cadastroServidor")
	public String save(@ModelAttribute ServidorPublico novoServidor, Model model)
	{
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<ServidorPublico> requestEntity = new HttpEntity<>(novoServidor, headers);

		ResponseEntity<ServidorPublico> response = restTemplate.exchange(
		"http://localhost:8080/cadastrarServidor",
		HttpMethod.POST,
		requestEntity,
		ServidorPublico.class);

		if (response.getStatusCode() == HttpStatus.CREATED) 
		    return "redirect:/listagemServidores"; 
		else 
		{
			model.addAttribute("mensagem", response.getStatusCode()); 
		    return "erro/mensagem";    
		}
	}
			
	
	@GetMapping("/formEditarServidor/{matricula}")
    public String formularioEditarServidor(@PathVariable Long matricula, Model model) {
		ResponseEntity<ServidorPublico> response = restTemplate.exchange(
                "http://localhost:8080/listarServidor/{matricula}", HttpMethod.GET, null,
                new ParameterizedTypeReference<ServidorPublico>() {},matricula);
        
    	ServidorPublico servidorEncontrado = response.getBody();
    	model.addAttribute("servidorpublico", servidorEncontrado);

        return "servidorpublico/editarservidorpublico";
    }

    @PostMapping("/edicaoServidor/{matricula}")
    public String update(@PathVariable Long matricula, @ModelAttribute ServidorPublico servidor) {
    	
    	HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<ServidorPublico> requestEntity = new HttpEntity<>(servidor, headers);

		ResponseEntity<ServidorPublico> response = restTemplate.exchange(
		"http://localhost:8080/editarServidor/{matricula}",
		HttpMethod.PUT,
		requestEntity,
		ServidorPublico.class,matricula);

		return "redirect:/listagemServidores"; 
    } 
    
	/***** API CURSOS ******/
	
    @GetMapping("/listagemCursos")
    public String getCursos(Model model) {
        
    	ResponseEntity<List<Curso>> response = restTemplate.exchange(
                "http://localhost:8080/listarCursos", HttpMethod.GET, null,
                new ParameterizedTypeReference<List<Curso>>() {});
        
    	List<Curso> cursosEncontrados = response.getBody();

    	// Adicione os dados dos clientes ao model
    	model.addAttribute("cursos", cursosEncontrados);

    	// Retorne a view Thymeleaf para renderização
    	return "curso/cursos";
    }
    
    @GetMapping("/listagemCurso/{idCurso}")
   	public String listByidCurso(@PathVariable("idCurso") long idCurso, Model model)
   	{
       	ResponseEntity<Curso> response = restTemplate.exchange(
                   "http://localhost:8080/listarCurso/{idCurso}", HttpMethod.GET, null,
                   new ParameterizedTypeReference<Curso>() {},idCurso);
           
       	Curso cursoEncontrado = response.getBody();

       	model.addAttribute("curso", cursoEncontrado);
       	
      	    return "curso/curso";	
   	}
   	
   	@GetMapping("/exclusaoCurso/{idCurso}")
   	public String deleteCurso(@PathVariable("idCurso") long idCurso) 
   	{
   		ResponseEntity<Void> response = restTemplate.exchange(
                   "http://localhost:8080/excluirCurso/{idCurso}", HttpMethod.DELETE, null,Void.class,
                   idCurso);
   		
   		return "redirect:/listagemCursos";
   	}   
   	
   	@GetMapping("/formNovoCurso")
   	public String formNovoCurso(Model model) {
   	    model.addAttribute("curso", new Curso());
   	    return "curso/novocurso";
   	}
   	
   	@PostMapping("/cadastroCurso")
   	public String save(@ModelAttribute Curso novoCurso, Model model)
   	{
   		
   		HttpHeaders headers = new HttpHeaders();
   		headers.setContentType(MediaType.APPLICATION_JSON);

   		HttpEntity<Curso> requestEntity = new HttpEntity<>(novoCurso, headers);

   		ResponseEntity<Curso> response = restTemplate.exchange(
   		"http://localhost:8080/cadastrarCurso",
   		HttpMethod.POST,
   		requestEntity,
   		Curso.class);

   		if (response.getStatusCode() == HttpStatus.CREATED) 
   		    return "redirect:/listagemCursos"; 
   		else 
   		{
   			model.addAttribute("mensagem", response.getStatusCode()); 
   		    return "erro/mensagem";    
   		}
   	}
   			
   	
   	@GetMapping("/formEditarCurso/{idCurso}")
       public String formularioEditarCurso(@PathVariable Long idCurso, Model model) {
   		ResponseEntity<Curso> response = restTemplate.exchange(
                   "http://localhost:8080/listarCurso/{idCurso}", HttpMethod.GET, null,
                   new ParameterizedTypeReference<Curso>() {},idCurso);
           
       	Curso cursoEncontrado = response.getBody();
       	model.addAttribute("curso", cursoEncontrado);

        return "curso/editarcurso";
       }

       @PostMapping("/edicaoCurso/{idCurso}")
       public String update(@PathVariable Long idCurso, @ModelAttribute Curso curso) {
       	
       	HttpHeaders headers = new HttpHeaders();
   		headers.setContentType(MediaType.APPLICATION_JSON);

   		HttpEntity<Curso> requestEntity = new HttpEntity<>(curso, headers);

   		ResponseEntity<Curso> response = restTemplate.exchange(
   		"http://localhost:8080/editarCurso/{idCurso}",
   		HttpMethod.PUT,
   		requestEntity,
   		Curso.class,idCurso);

   		return "redirect:/listagemCursos"; 
       } 
    
    @ExceptionHandler(ResponseStatusException.class)
	 public ResponseEntity<?> handleResponseStatusException(ResponseStatusException ex) {
		Map<String, Object> body = new LinkedHashMap<>(); 
	    body.put("message", ex.getReason()); 
	    body.put("status", ex.getStatusCode()); 
	    return new ResponseEntity<>(body, ex.getStatusCode());
	 }
}
