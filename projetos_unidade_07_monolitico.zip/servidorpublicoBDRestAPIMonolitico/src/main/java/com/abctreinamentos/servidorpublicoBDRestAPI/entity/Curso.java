package com.abctreinamentos.servidorpublicoBDRestAPI.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="curso")
public class Curso
{
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long idcurso;
		private String nome;
		private String foto;
		private String formarealizacao;
		private String ofertante;
		private Long vagas;
		private Double valor;
		private String site;
		private String situacao;

		
		public Curso()
		{
			
		}


		public Long getIdCurso() {
			return idcurso;
		}


		public void setIdCurso(Long idcurso) {
			this.idcurso = idcurso;
		}


		public String getNome() {
			return nome;
		}


		public void setNome(String nome) {
			this.nome = nome;
		}


		public String getFoto() {
			return foto;
		}


		public void setFoto(String foto) {
			this.foto = foto;
		}


		public String getFormarealizacao() {
			return formarealizacao;
		}


		public void setFormarealizacao(String formarealizacao) {
			this.formarealizacao = formarealizacao;
		}


		public String getOfertante() {
			return ofertante;
		}


		public void setOfertante(String ofertante) {
			this.ofertante = ofertante;
		}


		public Long getVagas() {
			return vagas;
		}


		public void setVagas(Long vagas) {
			this.vagas = vagas;
		}


		public Double getValor() {
			return valor;
		}


		public void setValor(Double valor) {
			this.valor = valor;
		}


		public String getSite() {
			return site;
		}


		public void setSite(String site) {
			this.site = site;
		}


		public String getSituacao() {
			return situacao;
		}


		public void setSituacao(String situacao) {
			this.situacao = situacao;
		}
		
		
		
}
