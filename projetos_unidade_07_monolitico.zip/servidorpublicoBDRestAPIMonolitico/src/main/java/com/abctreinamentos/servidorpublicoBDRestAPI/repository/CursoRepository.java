package com.abctreinamentos.servidorpublicoBDRestAPI.repository;

import org.springframework.stereotype.Repository;

import com.abctreinamentos.servidorpublicoBDRestAPI.entity.Curso;
import org.springframework.data.repository.CrudRepository;

@Repository
public interface CursoRepository extends CrudRepository<Curso, Long>
{

}
