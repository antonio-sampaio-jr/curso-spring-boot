package com.abctreinamentos.servidorpublico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServidorpublicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
