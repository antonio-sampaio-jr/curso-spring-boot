package com.abctreinamentos.servidorpublico;

import java.util.List;
import java.util.Optional;

import javax.swing.JOptionPane;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.abctreinamentos.servidorpublico.model.ServidorPublico;
import com.abctreinamentos.servidorpublico.service.ServidorPublicoService;

@Configuration
public class ServidorPublicoApplicationRunner implements CommandLineRunner {

	private ServidorPublicoService servidorService;
	
	@Autowired
	public void setServidorPublicoService(ServidorPublicoService servidorService)
	{
		this.servidorService = servidorService;
	}
	

	@Bean
	public void listAll()
	{
		List<ServidorPublico> servidoresPublicos = servidorService.listAll();
		
		if (servidoresPublicos.size() != 0) 
			servidoresPublicos.forEach(servidor -> 
			{
				System.out.println("**********************************");
				System.out.println(servidor.matricula());
				System.out.println(servidor.nome());
				System.out.println(servidor.cargo());
				System.out.println(servidor.celular());
				System.out.println(servidor.email());
				System.out.println(servidor.orgao());
			});
		else
			System.out.println("Arquivo Vazio!");
	}
	
	@Bean
	public void listByMatricula()
	{
		long matricula = Long.parseLong(JOptionPane.showInputDialog("Digite a matrícula do servidor:"));
		Optional<ServidorPublico> servidor = servidorService.listByMatricula(matricula);
		
		if (servidor.isPresent())
		{
				System.out.println("*********<<<<*************>>>>>************");
				System.out.println(servidor.get().matricula());
				System.out.println(servidor.get().nome());
				System.out.println(servidor.get().cargo());
				System.out.println(servidor.get().celular());
				System.out.println(servidor.get().email());
				System.out.println(servidor.get().orgao());
		}
		else
			System.out.println("Servidor Não Encontrado");
	}
	
	@Override
	public void run(String... args) throws Exception 
	{
		
	}

}
