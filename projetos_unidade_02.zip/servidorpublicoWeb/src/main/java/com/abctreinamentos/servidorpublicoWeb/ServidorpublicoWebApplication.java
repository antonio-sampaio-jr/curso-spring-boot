package com.abctreinamentos.servidorpublicoWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServidorpublicoWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServidorpublicoWebApplication.class, args);
	}

}
