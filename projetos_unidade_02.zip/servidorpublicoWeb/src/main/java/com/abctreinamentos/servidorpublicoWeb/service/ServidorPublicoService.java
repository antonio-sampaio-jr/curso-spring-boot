package com.abctreinamentos.servidorpublicoWeb.service;

import java.util.List;

import com.abctreinamentos.servidorpublicoWeb.model.ServidorPublico;

public interface ServidorPublicoService {
	
	List<ServidorPublico> listAll();
	
	ServidorPublico listByMatricula(long matricula);

}
