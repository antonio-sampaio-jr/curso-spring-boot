package com.abctreinamentos.cursomicroservice.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.abctreinamentos.cursomicroservice.entity.ServidorPublico;

@FeignClient(name="servidorpublico",url="http://192.168.0.201:8090")
public interface ServidorPublicoServiceClient {
	
	@GetMapping("/servidorpublico/listarServidores/{idcurso}")
	public List<ServidorPublico> listarServidoresCurso(@PathVariable long idcurso);

}
