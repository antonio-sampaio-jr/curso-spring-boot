package com.abctreinamentos.cursomicroservice.controller;

import java.util.List;
import java.util.Optional;
import java.util.Map;
import java.util.LinkedHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.abctreinamentos.cursomicroservice.api.CursoAPIRest;
import com.abctreinamentos.cursomicroservice.entity.Curso;
import com.abctreinamentos.cursomicroservice.entity.ServidorPublico;
import com.abctreinamentos.cursomicroservice.service.CursoService;

@RestController
@RequestMapping("/curso")
public class CursoController implements CursoAPIRest{
	
	private CursoService cursoService;
	
	@Autowired
	public void setCursoService(CursoService cursoService)
	{
		this.cursoService = cursoService;
	}

	@GetMapping("/listarCursos")
	public ResponseEntity<List<Curso>> listarCursos() {
		List<Curso> cursos = cursoService.listAll();
		return new ResponseEntity<List<Curso>>(cursos,HttpStatus.OK);
	}

	@GetMapping("/listarCurso/{idcurso}")
	public ResponseEntity<Curso> listarCurso(long idcurso) {
		
		Optional<Curso> cursoEncontrado = cursoService.listByIdCurso(idcurso);
		
		if (cursoEncontrado.isPresent())
			return new ResponseEntity<Curso>(cursoEncontrado.get(),HttpStatus.OK);
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Curso Não Encontrado");
	}

	@DeleteMapping("/excluirCurso/{idcurso}")
	public void excluirCurso(long idcurso) {
		
		Optional<Curso> cursoEncontrado = cursoService.listByIdCurso(idcurso);
		
		if (cursoEncontrado.isPresent())
		{
			cursoService.delete(idcurso);
			throw new ResponseStatusException(HttpStatus.OK,"Curso Excluído");
		}
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Curso Não Encontrado");
	}

	@PutMapping("/editarCurso/{idcurso}")
	public String editarCurso(long idcurso, @RequestBody Curso cursoAlterado) {
		
		Optional<Curso> cursoEncontrado = cursoService.listByIdCurso(idcurso);
		
		if (cursoEncontrado.isPresent())
		{
			cursoService.update(cursoAlterado);
			throw new ResponseStatusException(HttpStatus.OK,"Curso Alterado");
		}
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Curso Não Encontrado");

	}

	@PostMapping("/cadastrarCurso")
	public String cadastrarCurso(@RequestBody Curso novocurso) {
		
		cursoService.save(novocurso);
		throw new ResponseStatusException(HttpStatus.CREATED,"Curso Cadastrado");
	}
	
	
	@ExceptionHandler(ResponseStatusException.class)
	public ResponseEntity<Object> handleNotFoundException(ResponseStatusException ex) {
		Map<String, Object> body = new LinkedHashMap<>();
		body.put("message", ex.getReason());
		body.put("status", ex.getStatusCode());
		return new ResponseEntity<>(body, ex.getStatusCode());
	}

	@Override
	public ResponseEntity<List<ServidorPublico>> listarServidoresCurso(@PathVariable long idcurso) {
		List<ServidorPublico> servidores = cursoService.listarServidoresCurso(idcurso);
		
		if (!servidores.isEmpty())
			return new ResponseEntity<List<ServidorPublico>>(servidores,HttpStatus.OK);
		else
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Não existem Servidores Públicos cadastrados no Curso Informado");
	}
}
