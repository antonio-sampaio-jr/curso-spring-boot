package com.abctreinamentos.servidorpublicomicroservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abctreinamentos.servidorpublicomicroservice.entity.ServidorPublico;

@Repository
public interface ServidorPublicoRepository extends JpaRepository<ServidorPublico,Long> {

	List<ServidorPublico> findAllByIdcurso(Long idcurso);
	
}
